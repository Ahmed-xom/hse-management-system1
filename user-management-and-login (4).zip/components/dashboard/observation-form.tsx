"use client"

import { useState } from "react"
import { useAuth } from "@/lib/auth-context"
import { businessUnitsData } from "@/lib/business-units-data"
import { users } from "@/lib/users-data"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { format } from "date-fns"
import { CalendarIcon, Upload, Trash2, Plus, Eye, X } from "lucide-react"
import { cn } from "@/lib/utils"
import { Badge } from "@/components/ui/badge"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Separator } from "@/components/ui/separator"
import { toast } from "sonner"

// Observation Types
const observationTypes = [
  { value: "safe", label: "Safe Behaviour" },
  { value: "unsafe", label: "Unsafe Behaviour" },
  { value: "condition", label: "Unsafe Condition" },
  { value: "near-miss", label: "Near Miss" },
  { value: "positive", label: "Positive Observation" },
]

// Categories
const categories = [
  { value: "ppe", label: "PPE" },
  { value: "housekeeping", label: "Housekeeping" },
  { value: "equipment", label: "Equipment" },
  { value: "procedures", label: "Procedures" },
  { value: "environment", label: "Environment" },
  { value: "ergonomics", label: "Ergonomics" },
  { value: "chemical", label: "Chemical Handling" },
  { value: "electrical", label: "Electrical Safety" },
  { value: "fire", label: "Fire Safety" },
  { value: "other", label: "Other" },
]

// Locations
const locations = [
  { value: "site-a", label: "Site A - Main Office" },
  { value: "site-b", label: "Site B - Warehouse" },
  { value: "site-c", label: "Site C - Field Operations" },
  { value: "site-d", label: "Site D - Workshop" },
  { value: "site-e", label: "Site E - Storage Yard" },
]

// Near Miss Options
const nearMissOptions = [
  { value: "yes", label: "Yes" },
  { value: "no", label: "No" },
]

// Positions
const positions = [
  { value: "engineer", label: "Engineer" },
  { value: "supervisor", label: "Supervisor" },
  { value: "technician", label: "Technician" },
  { value: "operator", label: "Operator" },
  { value: "manager", label: "Manager" },
  { value: "safety-officer", label: "Safety Officer" },
]

// Action Item Types
const actionTypes = [
  { value: "corrective", label: "Corrective Action" },
  { value: "preventive", label: "Preventive Action" },
  { value: "improvement", label: "Improvement" },
]

// Priority Options
const priorityOptions = [
  { value: "high", label: "High" },
  { value: "medium", label: "Medium" },
  { value: "low", label: "Low" },
]

// Status Options
const statusOptions = [
  { value: "open", label: "Open" },
  { value: "in-progress", label: "In Progress" },
  { value: "closed", label: "Closed" },
]

interface ObservationDetail {
  id: string
  observationType: string
  category: string
}

interface ActionItem {
  id: string
  type: string
  action: string
  actionParty: string
  approver: string
  priority: string
  raisedDate: Date | undefined
  targetDate: Date | undefined
  status: string
  attachments: File[]
}

interface Attachment {
  id: string
  name: string
  file: File
}

export function ObservationForm() {
  const { user } = useAuth()
  const [date, setDate] = useState<Date>()
  const [businessUnit, setBusinessUnit] = useState("")
  const [observer, setObserver] = useState(user?.name || "")
  const [position, setPosition] = useState("")
  const [location, setLocation] = useState("")
  const [nearMiss, setNearMiss] = useState("")
  const [description, setDescription] = useState("")
  const [attachments, setAttachments] = useState<Attachment[]>([])
  const [observationDetails, setObservationDetails] = useState<ObservationDetail[]>([])
  const [correctiveActions, setCorrectiveActions] = useState("")
  const [actionItems, setActionItems] = useState<ActionItem[]>([])
  
  // New observation detail form
  const [newObsType, setNewObsType] = useState("")
  const [newObsCategory, setNewObsCategory] = useState("")
  
  // New action item form
  const [newActionType, setNewActionType] = useState("")
  const [newAction, setNewAction] = useState("")
  const [newActionParty, setNewActionParty] = useState("")
  const [newApprover, setNewApprover] = useState("")
  const [newPriority, setNewPriority] = useState("")
  const [newRaisedDate, setNewRaisedDate] = useState<Date>()
  const [newTargetDate, setNewTargetDate] = useState<Date>()
  const [newStatus, setNewStatus] = useState("")
  const [newActionAttachments, setNewActionAttachments] = useState<File[]>([])
  
  const [isActionDialogOpen, setIsActionDialogOpen] = useState(false)

  const activeBusinessUnits = businessUnitsData.filter(bu => bu.status === "Active")
  const activeUsers = users.filter(u => u.status === "Active")

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && attachments.length < 5) {
      const newFiles = Array.from(e.target.files).slice(0, 5 - attachments.length)
      const newAttachments = newFiles.map((file) => ({
        id: Math.random().toString(36).substr(2, 9),
        name: file.name,
        file,
      }))
      setAttachments([...attachments, ...newAttachments])
    }
  }

  const removeAttachment = (id: string) => {
    setAttachments(attachments.filter(a => a.id !== id))
  }

  const addObservationDetail = () => {
    if (newObsType && newObsCategory) {
      setObservationDetails([
        ...observationDetails,
        {
          id: Math.random().toString(36).substr(2, 9),
          observationType: newObsType,
          category: newObsCategory,
        },
      ])
      setNewObsType("")
      setNewObsCategory("")
    }
  }

  const removeObservationDetail = (id: string) => {
    setObservationDetails(observationDetails.filter(d => d.id !== id))
  }

  const addActionItem = () => {
    if (newActionType && newAction && newActionParty && newPriority && newStatus) {
      setActionItems([
        ...actionItems,
        {
          id: Math.random().toString(36).substr(2, 9),
          type: newActionType,
          action: newAction,
          actionParty: newActionParty,
          approver: newApprover,
          priority: newPriority,
          raisedDate: newRaisedDate,
          targetDate: newTargetDate,
          status: newStatus,
          attachments: newActionAttachments,
        },
      ])
      // Reset form
      setNewActionType("")
      setNewAction("")
      setNewActionParty("")
      setNewApprover("")
      setNewPriority("")
      setNewRaisedDate(undefined)
      setNewTargetDate(undefined)
      setNewStatus("")
      setNewActionAttachments([])
      setIsActionDialogOpen(false)
    }
  }

  const removeActionItem = (id: string) => {
    setActionItems(actionItems.filter(a => a.id !== id))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Submit form logic would go here
    toast.success("Observation submitted successfully!")
  }

  const getObsTypeLabel = (value: string) => observationTypes.find(t => t.value === value)?.label || value
  const getCategoryLabel = (value: string) => categories.find(c => c.value === value)?.label || value
  const getActionTypeLabel = (value: string) => actionTypes.find(t => t.value === value)?.label || value
  const getPriorityLabel = (value: string) => priorityOptions.find(p => p.value === value)?.label || value
  const getStatusLabel = (value: string) => statusOptions.find(s => s.value === value)?.label || value

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Observation Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Eye className="h-5 w-5" />
            New Behaviour Observation
          </CardTitle>
          <CardDescription>
            Report safety observations and behaviours in the workplace
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Basic Information */}
          <div className="grid gap-4 md:grid-cols-2">
            {/* Date */}
            <div className="space-y-2">
              <Label htmlFor="date">Date <span className="text-destructive">*</span></Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !date && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {date ? format(date, "PPP") : "Select date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar mode="single" selected={date} onSelect={setDate} initialFocus />
                </PopoverContent>
              </Popover>
            </div>

            {/* Business Unit */}
            <div className="space-y-2">
              <Label htmlFor="businessUnit">Business Unit <span className="text-destructive">*</span></Label>
              <Select value={businessUnit} onValueChange={setBusinessUnit}>
                <SelectTrigger>
                  <SelectValue placeholder="Select business unit" />
                </SelectTrigger>
                <SelectContent>
                  {activeBusinessUnits.map((bu) => (
                    <SelectItem key={bu.id} value={bu.name}>
                      {bu.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {businessUnit && (
                <p className="text-xs text-muted-foreground">Selected BU Summary. Click to view</p>
              )}
            </div>

            {/* Observer */}
            <div className="space-y-2">
              <Label htmlFor="observer">Observer <span className="text-destructive">*</span></Label>
              <Input
                id="observer"
                value={observer}
                onChange={(e) => setObserver(e.target.value)}
                placeholder="Observer name"
              />
            </div>

            {/* Position */}
            <div className="space-y-2">
              <Label htmlFor="position">Position <span className="text-destructive">*</span></Label>
              <Select value={position} onValueChange={setPosition}>
                <SelectTrigger>
                  <SelectValue placeholder="Select position" />
                </SelectTrigger>
                <SelectContent>
                  {positions.map((pos) => (
                    <SelectItem key={pos.value} value={pos.value}>
                      {pos.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Location */}
            <div className="space-y-2">
              <Label htmlFor="location">Location <span className="text-destructive">*</span></Label>
              <Select value={location} onValueChange={setLocation}>
                <SelectTrigger>
                  <SelectValue placeholder="Select location" />
                </SelectTrigger>
                <SelectContent>
                  {locations.map((loc) => (
                    <SelectItem key={loc.value} value={loc.value}>
                      {loc.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Near Miss */}
            <div className="space-y-2">
              <Label htmlFor="nearMiss">Near Miss <span className="text-destructive">*</span></Label>
              <Select value={nearMiss} onValueChange={setNearMiss}>
                <SelectTrigger>
                  <SelectValue placeholder="Select" />
                </SelectTrigger>
                <SelectContent>
                  {nearMissOptions.map((opt) => (
                    <SelectItem key={opt.value} value={opt.value}>
                      {opt.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Attachments */}
          <div className="space-y-2">
            <Label>Attachments</Label>
            <div className="rounded-lg border border-dashed p-4">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-12">No.</TableHead>
                    <TableHead>Attachment Name</TableHead>
                    <TableHead className="w-24">Remove</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {attachments.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={3} className="text-center text-muted-foreground">
                        No attachments added
                      </TableCell>
                    </TableRow>
                  ) : (
                    attachments.map((att, index) => (
                      <TableRow key={att.id}>
                        <TableCell>{index + 1}</TableCell>
                        <TableCell>{att.name}</TableCell>
                        <TableCell>
                          <Button
                            type="button"
                            variant="ghost"
                            size="icon"
                            onClick={() => removeAttachment(att.id)}
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
              <div className="mt-4 flex items-center gap-4">
                <input
                  type="file"
                  id="file-upload"
                  className="hidden"
                  multiple
                  onChange={handleFileUpload}
                  disabled={attachments.length >= 5}
                />
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => document.getElementById("file-upload")?.click()}
                  disabled={attachments.length >= 5}
                >
                  <Upload className="mr-2 h-4 w-4" />
                  Add File(s)
                </Button>
                <span className="text-xs text-muted-foreground">Maximum limit 5 items</span>
              </div>
            </div>
          </div>

          {/* Description */}
          <div className="space-y-2">
            <Label htmlFor="description">Description <span className="text-destructive">*</span></Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe the observation in detail..."
              rows={4}
            />
          </div>
        </CardContent>
      </Card>

      {/* Observation Type Card */}
      <Card>
        <CardHeader>
          <CardTitle>Observation Type</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label>Observation Type <span className="text-destructive">*</span></Label>
              <Select value={newObsType} onValueChange={setNewObsType}>
                <SelectTrigger>
                  <SelectValue placeholder="Select type" />
                </SelectTrigger>
                <SelectContent>
                  {observationTypes.map((type) => (
                    <SelectItem key={type.value} value={type.value}>
                      {type.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Category <span className="text-destructive">*</span></Label>
              <Select value={newObsCategory} onValueChange={setNewObsCategory}>
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((cat) => (
                    <SelectItem key={cat.value} value={cat.value}>
                      {cat.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <Button type="button" variant="outline" onClick={addObservationDetail} disabled={!newObsType || !newObsCategory}>
            <Plus className="mr-2 h-4 w-4" />
            Add Observation Type
          </Button>

          {/* Observation Details Table */}
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Observation Type</TableHead>
                <TableHead>Detail</TableHead>
                <TableHead className="w-20">Edit</TableHead>
                <TableHead className="w-20">Delete</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {observationDetails.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={4} className="text-center text-muted-foreground">
                    No observation types added
                  </TableCell>
                </TableRow>
              ) : (
                observationDetails.map((detail) => (
                  <TableRow key={detail.id}>
                    <TableCell>{getObsTypeLabel(detail.observationType)}</TableCell>
                    <TableCell>{getCategoryLabel(detail.category)}</TableCell>
                    <TableCell>
                      <Button type="button" variant="ghost" size="sm">Edit</Button>
                    </TableCell>
                    <TableCell>
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        onClick={() => removeObservationDetail(detail.id)}
                      >
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Action Taken Card */}
      <Card>
        <CardHeader>
          <CardTitle>Action Taken</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="correctiveActions">
              Description of Corrective Actions Taken (If Observation Unsafe) <span className="text-destructive">*</span>
            </Label>
            <Textarea
              id="correctiveActions"
              value={correctiveActions}
              onChange={(e) => setCorrectiveActions(e.target.value)}
              placeholder="Describe the corrective actions taken..."
              rows={4}
            />
          </div>
        </CardContent>
      </Card>

      {/* Action Items Card */}
      <Card>
        <CardHeader>
          <CardTitle>Action Items</CardTitle>
          <CardDescription>Non Conformance</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Dialog open={isActionDialogOpen} onOpenChange={setIsActionDialogOpen}>
            <DialogTrigger asChild>
              <Button type="button" variant="outline">
                <Plus className="mr-2 h-4 w-4" />
                Add Action Item
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Add Action Item</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label>Action Item Type <span className="text-destructive">*</span></Label>
                    <Select value={newActionType} onValueChange={setNewActionType}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent>
                        {actionTypes.map((type) => (
                          <SelectItem key={type.value} value={type.value}>
                            {type.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Priority <span className="text-destructive">*</span></Label>
                    <Select value={newPriority} onValueChange={setNewPriority}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select priority" />
                      </SelectTrigger>
                      <SelectContent>
                        {priorityOptions.map((pri) => (
                          <SelectItem key={pri.value} value={pri.value}>
                            {pri.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Action <span className="text-destructive">*</span></Label>
                  <Textarea
                    value={newAction}
                    onChange={(e) => setNewAction(e.target.value)}
                    placeholder="Describe the action..."
                    rows={3}
                  />
                </div>

                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label>Action Party <span className="text-destructive">*</span></Label>
                    <Select value={newActionParty} onValueChange={setNewActionParty}>
                      <SelectTrigger>
                        <SelectValue placeholder="Search for Action Party" />
                      </SelectTrigger>
                      <SelectContent>
                        {activeUsers.slice(0, 20).map((u) => (
                          <SelectItem key={u.id} value={u.name}>
                            {u.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Approver</Label>
                    <Select value={newApprover} onValueChange={setNewApprover}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select approver" />
                      </SelectTrigger>
                      <SelectContent>
                        {activeUsers.filter(u => u.role === "MANAGEMENT" || u.role === "SITE MANAGER" || u.role === "HSE ADMIN").map((u) => (
                          <SelectItem key={u.id} value={u.name}>
                            {u.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label>Raised Date <span className="text-destructive">*</span></Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className={cn(
                            "w-full justify-start text-left font-normal",
                            !newRaisedDate && "text-muted-foreground"
                          )}
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {newRaisedDate ? format(newRaisedDate, "PPP") : "Date Raised"}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar mode="single" selected={newRaisedDate} onSelect={setNewRaisedDate} initialFocus />
                      </PopoverContent>
                    </Popover>
                  </div>
                  <div className="space-y-2">
                    <Label>Target Date <span className="text-destructive">*</span></Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className={cn(
                            "w-full justify-start text-left font-normal",
                            !newTargetDate && "text-muted-foreground"
                          )}
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {newTargetDate ? format(newTargetDate, "PPP") : "Target Date"}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar mode="single" selected={newTargetDate} onSelect={setNewTargetDate} initialFocus />
                      </PopoverContent>
                    </Popover>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Status <span className="text-destructive">*</span></Label>
                  <Select value={newStatus} onValueChange={setNewStatus}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                    <SelectContent>
                      {statusOptions.map((status) => (
                        <SelectItem key={status.value} value={status.value}>
                          {status.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <Separator />

                <div className="flex justify-end gap-2">
                  <Button type="button" variant="outline" onClick={() => setIsActionDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button type="button" onClick={addActionItem}>
                    Add Action Item
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>

          {/* Action Items Table */}
          <div className="rounded-md border overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-12">No.</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Action</TableHead>
                  <TableHead>Action Party</TableHead>
                  <TableHead>Priority</TableHead>
                  <TableHead>Target Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="w-20">Edit</TableHead>
                  <TableHead className="w-20">Delete</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {actionItems.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={9} className="text-center text-muted-foreground">
                      No action items added
                    </TableCell>
                  </TableRow>
                ) : (
                  actionItems.map((item, index) => (
                    <TableRow key={item.id}>
                      <TableCell>{index + 1}</TableCell>
                      <TableCell>{getActionTypeLabel(item.type)}</TableCell>
                      <TableCell className="max-w-[200px] truncate">{item.action}</TableCell>
                      <TableCell>{item.actionParty}</TableCell>
                      <TableCell>
                        <Badge variant={item.priority === "high" ? "destructive" : item.priority === "medium" ? "default" : "secondary"}>
                          {getPriorityLabel(item.priority)}
                        </Badge>
                      </TableCell>
                      <TableCell>{item.targetDate ? format(item.targetDate, "PPP") : "-"}</TableCell>
                      <TableCell>
                        <Badge variant={item.status === "closed" ? "outline" : "default"}>
                          {getStatusLabel(item.status)}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Button type="button" variant="ghost" size="sm">Edit</Button>
                      </TableCell>
                      <TableCell>
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          onClick={() => removeActionItem(item.id)}
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Submit Button */}
      <div className="flex justify-end gap-4">
        <Button type="button" variant="outline">
          Save as Draft
        </Button>
        <Button type="submit">
          Submit Observation
        </Button>
      </div>
    </form>
  )
}
