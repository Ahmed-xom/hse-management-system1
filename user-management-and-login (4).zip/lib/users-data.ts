export interface User {
  id: string
  payrollNo: string
  name: string
  email: string
  password: string
  role: "ADMIN SYSTEM" | "MANAGEMENT" | "SITE MANAGER" | "SITE MANAGER - Global" | "HSE ADMIN" | "HSE" | "HR" | "MASTER USER" | "USER" | "USER - JM"
  designation: string
  businessUnit: string
  status: "Active" | "Inactive"
}

// Default password for all users
export const DEFAULT_PASSWORD = "Xom@2026"

// OTP sender email
export const OTP_SENDER_EMAIL = "XOM-Himaya@falconinvs.com"

// Base user data without password (password will be added dynamically)
type UserWithoutPassword = Omit<User, "password">

const baseUsers: UserWithoutPassword[] = [
  { id: "1", payrollNo: "XOM-DS-CON-0011", name: "Ahmed Abdalhamid Abbady", email: "aabbady@xomoman.com", role: "USER", designation: "Measurement & Logging While Drilling Engineer", businessUnit: "XOM Drilling System", status: "Active" },
  { id: "2", payrollNo: "XDS-DS--014", name: "Ahmed AB", email: "2@xomoman.com", role: "MANAGEMENT", designation: "Managing Director", businessUnit: "XOM Drilling System", status: "Inactive" },
  { id: "3", payrollNo: "1224", name: "xom xom xom (S)", email: "xom23@xomoman.com", role: "USER", designation: "Technical Director", businessUnit: "Falcon Oilfield Services", status: "Active" },
  { id: "4", payrollNo: "2ejd", name: "lmwdq kqnef ewqf (S)", email: "1@xomoman.com", role: "USER", designation: "Delivery Assurance Assistant Manager", businessUnit: "Falcon Oilfield Services", status: "Active" },
  { id: "5", payrollNo: "L-NSE-0281", name: "Ahmed Mohammed AL-Habsi", email: "ahabsi@falconofs.com", role: "USER", designation: "Store Man & Journey Manager", businessUnit: "Falcon Oilfield Services", status: "Inactive" },
  { id: "6", payrollNo: "L-XOM-0043", name: "Ib Hi Al (S)", email: "xom@xomoman.com", role: "USER", designation: "Electrician", businessUnit: "XOM Oman", status: "Inactive" },
  { id: "7", payrollNo: "i", name: "q293 dwd (S)", email: "xom1@xomoman.com", role: "USER", designation: "Assistant WL Operator", businessUnit: "Falcon Oilfield Services", status: "Inactive" },
  { id: "8", payrollNo: "E-FDS-0036", name: "Ahmed Mohammed Osama Ahmed", email: "aosama@xomoman.com", role: "USER", designation: "Directional Drilling Engineer", businessUnit: "XOM Drilling System", status: "Active" },
  { id: "9", payrollNo: "L-XOM-0052", name: "Ahmed Khalid Ahmed Al Zakwani", email: "aalzakwani@xomoman.com", role: "USER - JM", designation: "Journey manager / store keeper", businessUnit: "XOM Drilling System", status: "Active" },
  { id: "10", payrollNo: "L-328543", name: "IT Admin XOM (S)", email: "xom-it-admin@xomoman.com", role: "ADMIN SYSTEM", designation: "System Administrator", businessUnit: "XOM Oman", status: "Active" },
  { id: "11", payrollNo: "Approver", name: "Syed Sadaqat Approver", email: "syedsadaqat2494326@gmail.com", role: "MASTER USER", designation: "HSE Manager", businessUnit: "Falcon Oilfield Services", status: "Active" },
  { id: "12", payrollNo: "430974", name: "Rustam Khasanshin", email: "rkhasanshin@xomoman.com", role: "USER", designation: "Measurement & Logging While Drilling Engineer", businessUnit: "XOM Drilling System", status: "Active" },
  { id: "13", payrollNo: "L-XDS-0055", name: "Shaker Al Kathiri", email: "skathiri@xomoman.com", role: "USER", designation: "Directional Driller Trainee", businessUnit: "XOM Drilling System", status: "Active" },
  { id: "14", payrollNo: "L-XOM-0024", name: "Yousuf Mohsen Al-Hashmi", email: "yalhashmi@xomoman.com", role: "USER", designation: "MWD Trainee", businessUnit: "XOM Drilling System", status: "Active" },
  { id: "15", payrollNo: "L-XOM-0040", name: "Ibrahim Hilal Albusaidi (S)", email: "ibusaidi@xomoman.com", role: "USER", designation: "General Manager", businessUnit: "XOM Oman", status: "Active" },
  { id: "16", payrollNo: "L-NSE-0286", name: "Mohammed Hilal Ahmed AlKindi", email: "m.alkindi@falconofs.com", role: "USER - JM", designation: "Workshop Supervisor", businessUnit: "Falcon Oilfield Services", status: "Active" },
  { id: "17", payrollNo: "NSE-0285", name: "Sameh Salim AlHarthy", email: "sharthy@falconofs.com", role: "USER", designation: "Payroll Officer", businessUnit: "Falcon Oilfield Services", status: "Inactive" },
  { id: "18", payrollNo: "L-NSE-0284", name: "Laila Ahmed AlKindi", email: "lkindi@falconofs.com", role: "HR", designation: "Admin and HR", businessUnit: "Falcon Oilfield Services", status: "Active" },
  { id: "19", payrollNo: "L-NSE-0283", name: "Jabir Mohammed AlMahrouqi", email: "jmahrouqi@falconofs.com", role: "USER", designation: "Base Manager", businessUnit: "Falcon Oilfield Services", status: "Active" },
  { id: "20", payrollNo: "L-NSE-0282", name: "Mohammed Sulaiman Hassan Al-Balushi", email: "mbalushi@falconstaff.org", role: "USER", designation: "TCP Operator", businessUnit: "Falcon Oilfield Services", status: "Active" },
  { id: "21", payrollNo: "L-NSE-0280", name: "Shihab Hamad Mubarak Al-Abri", email: "salabri@falconofs.com", role: "MANAGEMENT", designation: "Field Engineer", businessUnit: "Falcon Oilfield Services", status: "Active" },
  { id: "22", payrollNo: "L-NSE-0279", name: "Tariq Salim Said Al-Kalbani", email: "tkalbani@falconofs.com", role: "MANAGEMENT", designation: "Base Supervisor", businessUnit: "Falcon Oilfield Services", status: "Active" },
  { id: "23", payrollNo: "L-NSE-0278", name: "Abdul Rahim Saif Ahmed Al-Kindi", email: "a.kindi@falconofs.com", role: "SITE MANAGER", designation: "Base Supervisor", businessUnit: "Falcon Oilfield Services", status: "Active" },
  { id: "24", payrollNo: "L-NSE-0277", name: "Hamed Hamood Said Al-Busaidi", email: "hbusaidi@falconstaff.org", role: "USER", designation: "Crew Chief", businessUnit: "Falcon Oilfield Services", status: "Active" },
  { id: "25", payrollNo: "L-NSE-0274", name: "Ali Rashid Moahmmed Al-Sawafi", email: "asawafi@falconstaff.org", role: "USER", designation: "Crew Chief", businessUnit: "Falcon Oilfield Services", status: "Active" },
  { id: "26", payrollNo: "L-NSE-0272", name: "Juma Khalid Al-Sabari", email: "jsabri@falconofs.com", role: "USER", designation: "TCP Engineer", businessUnit: "Falcon Oilfield Services", status: "Active" },
  { id: "27", payrollNo: "L-NSE-0271", name: "Anwar Saif Abdullah Al-KhayarI", email: "akhayari@falconstaff.org", role: "USER", designation: "Field Engineer", businessUnit: "Falcon Oilfield Services", status: "Active" },
  { id: "28", payrollNo: "L-NSE-0270", name: "Salim Hamood Salim Al-Shekaili", email: "s.alshekaili@falconstaff.org", role: "USER", designation: "Field Engineer", businessUnit: "Falcon Oilfield Services", status: "Active" },
  { id: "29", payrollNo: "L-NSE-0266", name: "Sharifa Ahmed Al-Sawwafi", email: "ssawwafi@falconofs.com", role: "USER", designation: "Accountant", businessUnit: "Falcon Oilfield Services", status: "Active" },
  { id: "30", payrollNo: "L-NSE-0262", name: "Idris Hamid Al-Mayahi", email: "imayahi@falconofs.com", role: "USER", designation: "Field Engineer", businessUnit: "Falcon Oilfield Services", status: "Active" },
  { id: "31", payrollNo: "L-NSE-0261", name: "Nasser Hamoud Al-Burtamani", email: "nburtamani@falconofs.com", role: "USER", designation: "TCP Engineer", businessUnit: "Falcon Oilfield Services", status: "Active" },
  { id: "32", payrollNo: "L-NSE-0248", name: "Huda Salim Sulaiman AlJahwari", email: "hjahwari@falconstaff.org", role: "USER", designation: "HSE Supervisor", businessUnit: "Falcon Oilfield Services", status: "Active" },
  { id: "33", payrollNo: "NSE-0256", name: "Hamood Hamed AlKhusaibi", email: "hkusaibi@falconstaff.org", role: "USER", designation: "Crew Chief", businessUnit: "Falcon Oilfield Services", status: "Inactive" },
  { id: "34", payrollNo: "L-NSE-0", name: "Samira Hamed Al Shukaili", email: "sam.shukaili@falconofs.com", role: "USER", designation: "Supply Chain Leader", businessUnit: "Falcon Oilfield Services", status: "Active" },
  { id: "35", payrollNo: "7804967", name: "Faisal Ishaqi", email: "f.alishaqi@falconofs.com", role: "USER", designation: "Finance manager", businessUnit: "Falcon Oilfield Services", status: "Active" },
  { id: "36", payrollNo: "LNSE0269", name: "Ibrahim Breiki", email: "ibreiki@falconofs.com", role: "MANAGEMENT", designation: "Operations Manager", businessUnit: "Falcon Oilfield Services", status: "Inactive" },
  { id: "37", payrollNo: "L-XDS-0050", name: "MAZIN Salim Yahya AL AZWANI", email: "mazwani@xomoman.com", role: "USER", designation: "MWD Trainee", businessUnit: "XOM Drilling System", status: "Active" },
  { id: "38", payrollNo: "E-NSE-0222", name: "Zeeshan Qamar", email: "zeeshan@falconstaff.org", role: "USER", designation: "Field Engineer", businessUnit: "Falcon Oilfield Services", status: "Active" },
  { id: "39", payrollNo: "E-NSE-0217", name: "yusral Bin Jamuir Sunur", email: "ysunur@falconstaff.org", role: "USER", designation: "Sonde Technician", businessUnit: "Falcon Oilfield Services", status: "Active" },
  { id: "40", payrollNo: "L-HIR-0046", name: "Waleed Mohammed Al Alawi", email: "walawi@falconofs.com", role: "USER", designation: "Mukaizna Field Engineer", businessUnit: "Falcon Oilfield Services", status: "Active" },
  { id: "41", payrollNo: "E-NSE-0226", name: "Tamer Mohammed Farghaly", email: "t.farghaly@falconstaff.org", role: "USER", designation: "PCE Specialist", businessUnit: "Falcon Oilfield Services", status: "Active" },
  { id: "42", payrollNo: "Tra001-XOM", name: "Muzna Mahfoodh Al Hadi", email: "mhadi@xomoman.com", role: "HR", designation: "Admin and HR", businessUnit: "XOM Drilling System", status: "Active" },
  { id: "43", payrollNo: "E-HIR-0076", name: "Muhammad Zeeshan Qadir", email: "mqadir@falconstaff.org", role: "USER", designation: "Field Engineer", businessUnit: "Falcon Oilfield Services", status: "Active" },
  { id: "44", payrollNo: "L-HIR-0044", name: "Mohammed Juma Al Rabaani", email: "mrabaani@falconofs.com", role: "USER", designation: "Maintenance Engineer", businessUnit: "Falcon Oilfield Services", status: "Active" },
  { id: "45", payrollNo: "L-NSE-0110", name: "Ishaq Ali Al Afeefi", email: "fofs-nz-elfm@falconofs.com", role: "USER", designation: "Workshop Foremen", businessUnit: "Falcon Oilfield Services", status: "Active" },
  { id: "46", payrollNo: "L-HIR-0041", name: "Hamed Yaqoob Al Yahyai", email: "hyahyai@falconstaff.org", role: "USER", designation: "Mukaizna Field Engineer", businessUnit: "Falcon Oilfield Services", status: "Active" },
  { id: "47", payrollNo: "L-HIR-0039", name: "Hamed Saif Al Shukaili", email: "hshekaili@falconofs.com", role: "USER", designation: "Field Operator", businessUnit: "Falcon Oilfield Services", status: "Active" },
  { id: "48", payrollNo: "L-HIRC-0001", name: "Bati Al yaqoubi", email: "bjuma@falconstaff.org", role: "USER", designation: "Mechanic", businessUnit: "Falcon Oilfield Services", status: "Active" },
  { id: "49", payrollNo: "L-FDS-0026", name: "Asad Saed Al-Rumaidhi", email: "aalrumaidhi@xomoman.com", role: "USER", designation: "Electronics Technician", businessUnit: "XOM Drilling System", status: "Active" },
  { id: "50", payrollNo: "L-HIRC-0002", name: "Ali Mabrook Al Tobi", email: "alitobi@falconstaff.org", role: "USER", designation: "PCE Specialist", businessUnit: "Falcon Oilfield Services", status: "Active" },
  { id: "51", payrollNo: "L-FDS-0019", name: "Abdullah Khamis Al-Hinai", email: "ahinai@xomoman.com", role: "USER", designation: "Motor Technician", businessUnit: "XOM Drilling System", status: "Active" },
  { id: "52", payrollNo: "E-XDS-0053", name: "Mounir Nessal", email: "mnessal@xomoman.com", role: "HSE ADMIN", designation: "Operations Manager", businessUnit: "XOM Drilling System", status: "Active" },
  { id: "53", payrollNo: "L-HIR-0042", name: "Khalid Said Al Hothaly", email: "khudhaili@falconofs.com", role: "USER", designation: "Mukaizna Field Engineer", businessUnit: "Falcon Oilfield Services", status: "Active" },
  { id: "54", payrollNo: "L-FINT-00017", name: "Adil AL-Shukaili", email: "ashukili@falconstaff.org", role: "USER", designation: "Field Engineer (Trainee)", businessUnit: "Falcon Oilfield Services", status: "Active" },
  { id: "55", payrollNo: "XOM-DS-SUB-001", name: "Sanaullah PIR Muhammad Khan", email: "sanaullahkh12374@gmail.com", role: "USER", designation: "Helper", businessUnit: "XOM Drilling System", status: "Active" },
  { id: "56", payrollNo: "L-XOMT-0037", name: "Muddathir Al Fahdi", email: "malfahdi@xomoman.com", role: "USER", designation: "Tool Technician", businessUnit: "XOM Drilling System", status: "Active" },
  { id: "57", payrollNo: "XOM-DS-CON-002", name: "Mazin Abdullah Al Kindi", email: "malkindi@xomoman.com", role: "USER", designation: "Electronics Technician", businessUnit: "XOM Drilling System", status: "Active" },
  { id: "58", payrollNo: "XOM-DS-CON-012", name: "Humaid Al Waili", email: "hwaili@xomoman.com", role: "USER", designation: "Measurement & Logging While Drilling Engineer", businessUnit: "XOM Drilling System", status: "Active" },
  { id: "59", payrollNo: "XOM-DS-CON-013", name: "Al Azhar Al Anbori", email: "humaid1979s@icloud.com", role: "USER", designation: "Measurement & Logging While Drilling Engineer", businessUnit: "XOM Drilling System", status: "Active" },
  { id: "60", payrollNo: "L-XOMT-0015", name: "Ahmed Al Khamisi", email: "akhamisi@xomoman.com", role: "USER - JM", designation: "Journey manager / store keeper", businessUnit: "XOM Drilling System", status: "Active" },
  { id: "61", payrollNo: "L-XOM-0042", name: "I H Al (S)", email: "i@xomoman.com", role: "USER", designation: "General Manager", businessUnit: "XOM Oman", status: "Active" },
  { id: "62", payrollNo: "22440026", name: "Shaker Al Kathiri", email: "skathiri@xon.com", role: "USER", designation: "Directional Drilling Engineer", businessUnit: "XOM Drilling System", status: "Inactive" },
  { id: "63", payrollNo: "XOM-DS-CON-004", name: "AbdelRahman Gamal", email: "agamal@xomoman.com", role: "SITE MANAGER", designation: "Reliability Engineer", businessUnit: "XOM Drilling System", status: "Active" },
  { id: "64", payrollNo: "FOFS-2025-01", name: "Syed Sadaqat HSEM", email: "ssadaqat@falconofs.com", role: "SITE MANAGER - Global", designation: "QHSE Manager", businessUnit: "Falcon Oilfield Services", status: "Active" },
  { id: "65", payrollNo: "L-FINT-00038", name: "Turki Al Kharusi", email: "tkharusi@xomoman.com", role: "USER", designation: "Measurement & Logging While Drilling Engineer", businessUnit: "XOM Drilling System", status: "Inactive" },
  { id: "66", payrollNo: "FDS-Consultant", name: "Salim Saif Al-Abri", email: "sabri@xomoman.com", role: "USER", designation: "Measurement & Logging While Drilling Engineer", businessUnit: "XOM Drilling System", status: "Inactive" },
  { id: "67", payrollNo: "L-FINT-00022", name: "Omar Khalfan Al-Amri", email: "oaamri@xomoman.com", role: "USER", designation: "Measurement & Logging While Drilling Engineer", businessUnit: "XOM Drilling System", status: "Active" },
  { id: "68", payrollNo: "L-FDS-0046", name: "Mahmood Mohammed Mustafa Najjar", email: "mnajjar@xomoman.com", role: "USER", designation: "Measurement & Logging While Drilling Engineer", businessUnit: "XOM Drilling System", status: "Inactive" },
  { id: "69", payrollNo: "L-FINT-00020", name: "Liyth Ambusaidi", email: "lambusaidi@xomoman.com", role: "USER", designation: "Measurement & Logging While Drilling Engineer", businessUnit: "XOM Drilling System", status: "Active" },
  { id: "70", payrollNo: "L-FDS-0043", name: "Abdullah Sulaiman Hamdan Al Aamri", email: "aamri@xomoman.com", role: "USER", designation: "Measurement & Logging While Drilling Engineer", businessUnit: "XOM Drilling System", status: "Active" },
  { id: "71", payrollNo: "L-FDS-0056", name: "Ahmed Hamed Al JUFAILI", email: "ajufaily@xomoman.com", role: "USER", designation: "Directional Drilling Engineer", businessUnit: "XOM Drilling System", status: "Active" },
  { id: "72", payrollNo: "L-FDS-0032", name: "Abdullah Sulaiman Al-Aamri", email: "aamri@gmail.com", role: "USER", designation: "Directional Driller Trainee", businessUnit: "XOM Drilling System", status: "Inactive" },
  { id: "73", payrollNo: "XOM-DS-C-006", name: "Ahmed Khalid Ahmed Al Zakwani", email: "azakwani@xomoman.com", role: "USER - JM", designation: "Field Operator", businessUnit: "XOM Drilling System", status: "Inactive" },
  { id: "74", payrollNo: "XOM-DS-031", name: "Hashim Ali Mubarak Al Farsi", email: "hfarsi@xomoman.com", role: "SITE MANAGER", designation: "Service Quality", businessUnit: "XOM Drilling System", status: "Active" },
  { id: "75", payrollNo: "E-NSE-0228", name: "Sohail Khan Jadoon", email: "sjadoon@falconstaff.org", role: "USER", designation: "Field Engineer", businessUnit: "Falcon Oilfield Services", status: "Active" },
  { id: "76", payrollNo: "XWM-SUB-004", name: "Suhail Mohammed", email: "suhail.mohammed@barikgroup.com", role: "USER", designation: "3rd Party Contractor", businessUnit: "XOM Well Maintenance", status: "Active" },
  { id: "77", payrollNo: "L-FINT-00019", name: "BASIM Ghasi AL Rahbi", email: "b.rahbi@falconstaff.org", role: "USER", designation: "Field Engineer (Trainee)", businessUnit: "Falcon Oilfield Services", status: "Active" },
  { id: "78", payrollNo: "L-FINT-00018", name: "Asad Said AL-Yahyaai", email: "a.yayaai@falconstaff.org", role: "USER", designation: "Field Engineer (Trainee)", businessUnit: "Falcon Oilfield Services", status: "Inactive" },
  { id: "79", payrollNo: "L-HIR-0119", name: "Mohammed Hamed Ali Al Shaaili", email: "mohd95516054@gmail.com", role: "USER", designation: "Helper", businessUnit: "XOM Well Maintenance", status: "Active" },
  { id: "80", payrollNo: "BARIK-XWM-002", name: "Faisal Said Khalfan Al Harthy", email: "faisalg3588455@gmail.com", role: "USER", designation: "WHM Operator", businessUnit: "XOM Well Maintenance", status: "Active" },
  { id: "81", payrollNo: "BARIK-XWM-003", name: "Fahad Majiid", email: "fahadhpam@gmail.com", role: "USER", designation: "WHM Operator", businessUnit: "XOM Well Maintenance", status: "Active" },
  { id: "82", payrollNo: "BARIK-XWM-01", name: "Nasser Al Mamari", email: "nasser88almamari@gmail.com", role: "USER", designation: "WHM Operator", businessUnit: "XOM Well Maintenance", status: "Active" },
  { id: "83", payrollNo: "L-HIR-0127", name: "Montasar Ahmed Rashid Al-Habsi", email: "mun9911@icloud.com", role: "USER", designation: "Helper", businessUnit: "XOM Well Maintenance", status: "Active" },
  { id: "84", payrollNo: "E-NSE-0221", name: "Islam Mohamad Gaber", email: "islam.gaber@falconofs.com", role: "USER", designation: "Field Engineer", businessUnit: "Falcon Oilfield Services", status: "Active" },
  { id: "85", payrollNo: "E-NSE-0224", name: "Hammad Shoukat", email: "mhammad@falconstaff.org", role: "USER", designation: "Field Engineer", businessUnit: "Falcon Oilfield Services", status: "Active" },
  { id: "86", payrollNo: "L-FINT-00039", name: "AL-Zaina Zayid AL-Rujaibi", email: "a.rujaibi@falconstaff.org", role: "USER", designation: "Field Engineer (Trainee)", businessUnit: "Falcon Oilfield Services", status: "Active" },
  { id: "87", payrollNo: "E-NSE-0229", name: "Akhilesh Chopra", email: "akhilesh@falconstaff.org", role: "USER", designation: "Field Engineer", businessUnit: "Falcon Oilfield Services", status: "Inactive" },
  { id: "88", payrollNo: "E-NSE-0225", name: "Fahad Hamad Ghalib", email: "fhamed@falconstaff.org", role: "USER", designation: "Field Engineer", businessUnit: "Falcon Oilfield Services", status: "Active" },
  { id: "89", payrollNo: "L-FINT-0003", name: "Ahmed Said Al-Kabi", email: "xwm-admin-sr@xomoman.com", role: "HR", designation: "Operations Support", businessUnit: "XOM Well Maintenance", status: "Active" },
  { id: "90", payrollNo: "XOM-0056", name: "Mohammed Saif Al Busaidi", email: "mbusaidi@xomoman.com", role: "MANAGEMENT", designation: "Supply Chain & Administration Manager", businessUnit: "XOM LLC", status: "Active" },
  { id: "91", payrollNo: "FAL-FWM-SUB-003", name: "Sajid Majid", email: "sajid.majeed@barikgroup.com", role: "USER", designation: "Operations Support", businessUnit: "XOM Well Maintenance", status: "Active" },
  { id: "92", payrollNo: "FAL-FWM-SUB-002", name: "Praveen Kumar", email: "qhse02.bg@barikgroup.com", role: "USER", designation: "HSE Supervisor", businessUnit: "XOM Well Maintenance", status: "Active" },
  { id: "93", payrollNo: "FAL-FWM-SUB-001", name: "Harish VC", email: "harish.vc@barikgroup.com", role: "USER", designation: "Operations Support", businessUnit: "XOM Well Maintenance", status: "Active" },
  { id: "94", payrollNo: "L-FWM-0049", name: "Abdallah Ali Mohammed Al Busaidy", email: "abusaidi@xomoman.com", role: "USER", designation: "HSE Supervisor", businessUnit: "XOM Well Maintenance", status: "Active" },
  { id: "95", payrollNo: "L-FINT003", name: "Ahmed Al Kaabi", email: "a.alkaabi@falconstaff.org", role: "HR", designation: "Admin and HR", businessUnit: "XOM Well Maintenance", status: "Inactive" },
  { id: "96", payrollNo: "E-NSE-0216", name: "Waqas Ahmed", email: "awaqas@falconstaff.org", role: "USER", designation: "Field Engineer", businessUnit: "Falcon Oilfield Services", status: "Active" },
  { id: "97", payrollNo: "E-FIN-0043", name: "Aziza Said Al Bimany", email: "abimani@falconofs.com", role: "HR", designation: "Administrator Assistant", businessUnit: "XOM LLC", status: "Inactive" },
  { id: "98", payrollNo: "LFINT00025", name: "Sabra Saud AL-Tiwaniy", email: "falcon.hr@falconstaff.org", role: "HR", designation: "Admin and HR", businessUnit: "XOM LLC", status: "Active" },
  { id: "99", payrollNo: "E-FIN-0045", name: "Ali Nemati", email: "anemati@falconofs.com", role: "SITE MANAGER", designation: "supply chain officer", businessUnit: "XOM Oman", status: "Inactive" },
  { id: "100", payrollNo: "L-HIR-0060", name: "Ali Salim Al Aisri", email: "alimatata88@hotmail.com", role: "USER", designation: "Senior Field Operator", businessUnit: "Falcon Oilfield Services", status: "Active" },
]

// Add password to all users dynamically
export const users: User[] = baseUsers.map(user => ({
  ...user,
  password: DEFAULT_PASSWORD
}))

// Mutable user store for runtime changes (add/edit/delete users)
let runtimeUsers: User[] = [...users]

export function getUsers(): User[] {
  return runtimeUsers
}

export function addUser(user: Omit<User, "id" | "password">): User {
  const newId = (Math.max(...runtimeUsers.map(u => parseInt(u.id))) + 1).toString()
  const newUser: User = {
    ...user,
    id: newId,
    password: DEFAULT_PASSWORD
  }
  runtimeUsers = [...runtimeUsers, newUser]
  return newUser
}

export function updateUser(id: string, updates: Partial<Omit<User, "id">>): User | null {
  const index = runtimeUsers.findIndex(u => u.id === id)
  if (index === -1) return null
  
  runtimeUsers[index] = { ...runtimeUsers[index], ...updates }
  return runtimeUsers[index]
}

export function resetUserPassword(id: string): boolean {
  const index = runtimeUsers.findIndex(u => u.id === id)
  if (index === -1) return false
  
  runtimeUsers[index] = { ...runtimeUsers[index], password: DEFAULT_PASSWORD }
  return true
}

export function deleteUser(id: string): boolean {
  const index = runtimeUsers.findIndex(u => u.id === id)
  if (index === -1) return false
  
  runtimeUsers = runtimeUsers.filter(u => u.id !== id)
  return true
}

export function findUserByEmail(email: string): User | undefined {
  return runtimeUsers.find(u => u.email.toLowerCase() === email.toLowerCase())
}

export function validatePassword(email: string, password: string): User | null {
  const user = findUserByEmail(email)
  if (!user) return null
  if (user.password !== password) return null
  if (user.status === "Inactive") return null
  return user
}

// OTP store (in-memory for demo, use database in production)
const otpStore: Map<string, { otp: string; expires: number }> = new Map()

export function generateOTP(email: string): string {
  const otp = Math.floor(100000 + Math.random() * 900000).toString()
  otpStore.set(email.toLowerCase(), {
    otp,
    expires: Date.now() + 10 * 60 * 1000 // 10 minutes
  })
  return otp
}

export function verifyOTP(email: string, otp: string): boolean {
  const stored = otpStore.get(email.toLowerCase())
  if (!stored) return false
  if (Date.now() > stored.expires) {
    otpStore.delete(email.toLowerCase())
    return false
  }
  if (stored.otp !== otp) return false
  otpStore.delete(email.toLowerCase())
  return true
}

export function setNewPassword(email: string, newPassword: string): boolean {
  const index = runtimeUsers.findIndex(u => u.email.toLowerCase() === email.toLowerCase())
  if (index === -1) return false
  runtimeUsers[index] = { ...runtimeUsers[index], password: newPassword }
  return true
}
