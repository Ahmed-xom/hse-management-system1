"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { 
  getUsers, 
  validatePassword, 
  findUserByEmail, 
  generateOTP, 
  verifyOTP, 
  setNewPassword,
  addUser,
  updateUser,
  resetUserPassword,
  deleteUser,
  OTP_SENDER_EMAIL,
  DEFAULT_PASSWORD,
  type User 
} from "./users-data"

// Admin email
const ADMIN_EMAIL = "xom-it-admin@xomoman.com"

interface AuthContextType {
  user: User | null
  isAdmin: boolean
  isLoading: boolean
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>
  logout: () => void
  requestPasswordReset: (email: string) => Promise<{ success: boolean; error?: string; otp?: string }>
  verifyOTPCode: (email: string, otp: string) => Promise<{ success: boolean; error?: string }>
  resetPassword: (email: string, newPassword: string) => Promise<{ success: boolean; error?: string }>
  // Admin functions
  getAllUsers: () => User[]
  createUser: (userData: Omit<User, "id" | "password">) => Promise<{ success: boolean; error?: string; user?: User }>
  editUser: (id: string, updates: Partial<Omit<User, "id">>) => Promise<{ success: boolean; error?: string }>
  adminResetPassword: (userId: string) => Promise<{ success: boolean; error?: string }>
  removeUser: (id: string) => Promise<{ success: boolean; error?: string }>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Check for existing session
    const storedUser = localStorage.getItem("hse_user")
    if (storedUser) {
      try {
        const parsed = JSON.parse(storedUser)
        // Verify user still exists and is active
        const currentUser = findUserByEmail(parsed.email)
        if (currentUser && currentUser.status === "Active") {
          setUser(currentUser)
        } else {
          localStorage.removeItem("hse_user")
        }
      } catch {
        localStorage.removeItem("hse_user")
      }
    }
    setIsLoading(false)
  }, [])

  const login = async (email: string, password: string): Promise<{ success: boolean; error?: string }> => {
    // Validate credentials
    const foundUser = validatePassword(email, password)

    if (!foundUser) {
      // Check if user exists but wrong password
      const userExists = findUserByEmail(email)
      if (!userExists) {
        return { success: false, error: "User not found. Please contact your administrator." }
      }
      if (userExists.status === "Inactive") {
        return { success: false, error: "Your account is inactive. Please contact your administrator." }
      }
      return { success: false, error: "Invalid password. Please try again." }
    }

    // Set user in state and localStorage
    setUser(foundUser)
    localStorage.setItem("hse_user", JSON.stringify(foundUser))
    return { success: true }
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem("hse_user")
  }

  const requestPasswordReset = async (email: string): Promise<{ success: boolean; error?: string; otp?: string }> => {
    // Find user by email
    const foundUser = findUserByEmail(email)

    if (!foundUser) {
      return { success: false, error: "Email not found in our system." }
    }

    try {
      // Send OTP via API (which sends email from XOM-Himaya@falconinvs.com)
      const response = await fetch("/api/send-otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, action: "send" })
      })
      
      const result = await response.json()
      
      if (!result.success) {
        return { success: false, error: result.error || "Failed to send OTP" }
      }

      // Also store locally for verification (fallback)
      generateOTP(email)
      
      // For demo, return the OTP (remove in production)
      return { success: true, otp: result.debug?.otp }
    } catch (error) {
      console.error("Failed to send OTP:", error)
      // Fallback to local OTP generation
      const otp = generateOTP(email)
      console.log(`[OTP] Sending OTP ${otp} to ${email} from ${OTP_SENDER_EMAIL}`)
      return { success: true, otp }
    }
  }

  const verifyOTPCode = async (email: string, otp: string): Promise<{ success: boolean; error?: string }> => {
    const isValid = verifyOTP(email, otp)
    if (!isValid) {
      return { success: false, error: "Invalid or expired OTP. Please try again." }
    }
    return { success: true }
  }

  const resetPassword = async (email: string, newPassword: string): Promise<{ success: boolean; error?: string }> => {
    const success = setNewPassword(email, newPassword)
    if (!success) {
      return { success: false, error: "Failed to reset password." }
    }
    return { success: true }
  }

  // Admin functions
  const getAllUsers = (): User[] => {
    return getUsers()
  }

  const createUser = async (userData: Omit<User, "id" | "password">): Promise<{ success: boolean; error?: string; user?: User }> => {
    // Check if email already exists
    const existingUser = findUserByEmail(userData.email)
    if (existingUser) {
      return { success: false, error: "A user with this email already exists." }
    }

    const newUser = addUser(userData)
    return { success: true, user: newUser }
  }

  const editUser = async (id: string, updates: Partial<Omit<User, "id">>): Promise<{ success: boolean; error?: string }> => {
    // If changing email, check it doesn't conflict
    if (updates.email) {
      const existingUser = findUserByEmail(updates.email)
      if (existingUser && existingUser.id !== id) {
        return { success: false, error: "A user with this email already exists." }
      }
    }

    const updated = updateUser(id, updates)
    if (!updated) {
      return { success: false, error: "User not found." }
    }
    return { success: true }
  }

  const adminResetPassword = async (userId: string): Promise<{ success: boolean; error?: string }> => {
    const success = resetUserPassword(userId)
    if (!success) {
      return { success: false, error: "User not found." }
    }
    return { success: true }
  }

  const removeUser = async (id: string): Promise<{ success: boolean; error?: string }> => {
    const success = deleteUser(id)
    if (!success) {
      return { success: false, error: "User not found." }
    }
    return { success: true }
  }

  const isAdmin = user?.email.toLowerCase() === ADMIN_EMAIL.toLowerCase()

  return (
    <AuthContext.Provider value={{ 
      user, 
      isAdmin, 
      isLoading, 
      login, 
      logout, 
      requestPasswordReset,
      verifyOTPCode,
      resetPassword,
      getAllUsers,
      createUser,
      editUser,
      adminResetPassword,
      removeUser
    }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}

export { DEFAULT_PASSWORD, OTP_SENDER_EMAIL }
