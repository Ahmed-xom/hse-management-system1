"use client"

import { UserManagement } from "@/components/admin/user-management"

export default function AdminPage() {
  return (
    <div className="container mx-auto py-6 px-4 md:px-6">
      <UserManagement />
    </div>
  )
}
