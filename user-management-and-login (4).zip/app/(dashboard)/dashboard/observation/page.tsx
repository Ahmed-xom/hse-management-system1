import { DashboardHeader } from "@/components/dashboard/header"
import { ObservationForm } from "@/components/dashboard/observation-form"

export default function ObservationPage() {
  return (
    <div className="min-h-screen bg-background">
      <DashboardHeader />
      <main className="mx-auto max-w-[1200px] px-4 py-6 sm:px-6 lg:px-8">
        {/* Page Title */}
        <div className="mb-6 flex flex-col gap-1">
          <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">New Observation</h1>
          <p className="text-muted-foreground">
            Report behaviour observations for safety improvement
          </p>
        </div>

        {/* Observation Form */}
        <ObservationForm />
      </main>

      {/* Footer */}
      <footer className="border-t border-border/50 bg-card/30 mt-8">
        <div className="mx-auto max-w-[1600px] px-4 py-6 sm:px-6 lg:px-8">
          <div className="flex flex-col items-center justify-between gap-4 sm:flex-row">
            <p className="text-sm text-muted-foreground">
              © 2024 XOM Oman HSE Portal. All rights reserved.
            </p>
            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              <a href="#" className="transition-colors hover:text-foreground">Privacy Policy</a>
              <a href="#" className="transition-colors hover:text-foreground">Terms of Service</a>
              <a href="#" className="transition-colors hover:text-foreground">Support</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
