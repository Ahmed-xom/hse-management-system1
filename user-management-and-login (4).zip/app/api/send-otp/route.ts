import { NextRequest, NextResponse } from "next/server"
import nodemailer from "nodemailer"
import { findUserByEmail } from "@/lib/users-data"

// OTP sender email configuration
const OTP_SENDER_EMAIL = "XOM-Himaya@falconinvs.com"
const OTP_SENDER_NAME = "XOM Himaya HSE System"

// Store OTPs temporarily (in production, use Redis or database)
const otpStore = new Map<string, { otp: string; expiresAt: number }>()

// Create SMTP transporter
function createTransporter() {
  return nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: parseInt(process.env.SMTP_PORT || "587"),
    secure: process.env.SMTP_SECURE === "true", // true for 465, false for other ports
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASSWORD,
    },
  })
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { email, action, otp: providedOtp } = body

    if (!email) {
      return NextResponse.json({ success: false, error: "Email is required" }, { status: 400 })
    }

    if (action === "send") {
      // Verify user exists
      const user = findUserByEmail(email)
      if (!user) {
        return NextResponse.json({ success: false, error: "Email not found in our system" }, { status: 404 })
      }

      // Generate 6-digit OTP
      const otp = Math.floor(100000 + Math.random() * 900000).toString()
      const expiresAt = Date.now() + 10 * 60 * 1000 // 10 minutes

      // Store OTP
      otpStore.set(email.toLowerCase(), { otp, expiresAt })

      // Check if SMTP is configured
      if (!process.env.SMTP_HOST || !process.env.SMTP_USER || !process.env.SMTP_PASSWORD) {
        console.log(`[OTP] SMTP not configured. OTP for ${email}: ${otp}`)
        return NextResponse.json({ 
          success: true, 
          message: "OTP generated (SMTP not configured)",
          debug: { otp } // Remove in production
        })
      }

      // Send email via SMTP
      try {
        const transporter = createTransporter()

        const mailOptions = {
          from: `"${OTP_SENDER_NAME}" <${OTP_SENDER_EMAIL}>`,
          to: email,
          subject: "Password Reset OTP - XOM HSE Dashboard",
          html: `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
              <div style="background: linear-gradient(135deg, #1e3a5f 0%, #2d5a87 100%); padding: 30px; border-radius: 10px 10px 0 0;">
                <h1 style="color: white; margin: 0; font-size: 24px;">XOM HSE Dashboard</h1>
                <p style="color: #a3c9e8; margin: 5px 0 0 0;">Password Reset Request</p>
              </div>
              <div style="background: #f8fafc; padding: 30px; border: 1px solid #e2e8f0; border-top: none;">
                <p style="color: #334155; font-size: 16px; margin-bottom: 20px;">
                  Hello <strong>${user.name}</strong>,
                </p>
                <p style="color: #334155; font-size: 16px; margin-bottom: 20px;">
                  You have requested to reset your password. Use the OTP below to proceed:
                </p>
                <div style="background: #1e3a5f; padding: 20px; border-radius: 8px; text-align: center; margin: 25px 0;">
                  <span style="color: white; font-size: 32px; font-weight: bold; letter-spacing: 8px;">${otp}</span>
                </div>
                <p style="color: #64748b; font-size: 14px; margin-top: 20px;">
                  This OTP is valid for <strong>10 minutes</strong>. Do not share this code with anyone.
                </p>
                <p style="color: #64748b; font-size: 14px;">
                  If you did not request this password reset, please ignore this email or contact your administrator.
                </p>
              </div>
              <div style="background: #1e293b; padding: 20px; border-radius: 0 0 10px 10px; text-align: center;">
                <p style="color: #94a3b8; font-size: 12px; margin: 0;">
                  This is an automated message from XOM HSE Dashboard.<br>
                  Please do not reply to this email.
                </p>
              </div>
            </div>
          `,
          text: `
XOM HSE Dashboard - Password Reset

Hello ${user.name},

You have requested to reset your password. Your OTP is: ${otp}

This OTP is valid for 10 minutes. Do not share this code with anyone.

If you did not request this password reset, please ignore this email.

- XOM Himaya HSE Team
          `
        }

        await transporter.sendMail(mailOptions)

        return NextResponse.json({ 
          success: true, 
          message: `OTP sent to ${email}` 
        })

      } catch (emailError) {
        console.error("[SMTP Error]:", emailError)
        // Return OTP in debug for testing if email fails
        return NextResponse.json({ 
          success: true, 
          message: "OTP generated (email send failed)",
          debug: { otp },
          error: "Email delivery failed, but OTP was generated"
        })
      }
    }

    if (action === "verify") {
      const stored = otpStore.get(email.toLowerCase())

      if (!stored) {
        return NextResponse.json({ success: false, error: "No OTP found. Please request a new one." }, { status: 400 })
      }

      if (Date.now() > stored.expiresAt) {
        otpStore.delete(email.toLowerCase())
        return NextResponse.json({ success: false, error: "OTP has expired. Please request a new one." }, { status: 400 })
      }

      if (stored.otp !== providedOtp) {
        return NextResponse.json({ success: false, error: "Invalid OTP" }, { status: 400 })
      }

      // OTP is valid - delete it so it can't be reused
      otpStore.delete(email.toLowerCase())

      return NextResponse.json({ success: true, message: "OTP verified successfully" })
    }

    return NextResponse.json({ success: false, error: "Invalid action" }, { status: 400 })
  } catch (error) {
    console.error("OTP API error:", error)
    return NextResponse.json({ success: false, error: "Internal server error" }, { status: 500 })
  }
}
